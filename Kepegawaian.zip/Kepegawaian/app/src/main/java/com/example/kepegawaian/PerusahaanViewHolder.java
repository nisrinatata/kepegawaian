package com.example.kepegawaian;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PerusahaanViewHolder extends RecyclerView.ViewHolder {
    public TextView tvnama;
    public TextView tvruangan;
    public TextView tvkategori;
    public TextView tvkeluhan;
    public TextView tvfoto;
    public TextView btnopen;

    public PerusahaanViewHolder( View itemView) {
        super(itemView);

        tvfoto = itemView.findViewById(R.id.tv_foto);
        tvkategori = itemView.findViewById(R.id.tv_kategori);
        tvkeluhan = itemView.findViewById(R.id.tv_keluhan);
        tvnama = itemView.findViewById(R.id.tv_nama);
        tvruangan = itemView.findViewById(R.id.tv_ruangan);
        btnopen = itemView.findViewById(R.id.btn_open);
    }
    public void bindToPerusahaan(Perusahaan perusahaan, View.OnClickListener onClickListener){

        tvfoto.setText(perusahaan.foto);
        tvkategori.setText(perusahaan.kategori);
        tvkeluhan.setText(perusahaan.keluhan);
        tvnama.setText(perusahaan.nama);
        tvruangan.setText(perusahaan.ruangan);
        btnopen.setOnClickListener(onClickListener);
    }
}
