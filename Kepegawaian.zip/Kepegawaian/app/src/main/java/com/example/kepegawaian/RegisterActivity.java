package com.example.kepegawaian;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void Click2(View view){

        EditText et_nama =  (EditText)findViewById(R.id.et_nama);
        EditText et_hp =  (EditText)findViewById(R.id.et_hp);

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        //Referensi database yang dituju
        DatabaseReference myRef =
                database.getReference();
        myRef.child("Nama").setValue(et_nama.getText().toString());
        myRef.child("No Hp").setValue(et_hp.getText().toString());
        //memberi nilai pada referensi yang dituju


    }
}