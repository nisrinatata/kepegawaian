package com.example.kepegawaian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
        public void Click1(View view){

    EditText  et_nama =  (EditText)findViewById(R.id.et_nama);
    EditText  et_ttl =  (EditText)findViewById(R.id.et_ttl);
    EditText  et_almt = (EditText) findViewById(R.id.et_almt);

    FirebaseDatabase database = FirebaseDatabase.getInstance();

    //Referensi database yang dituju
    DatabaseReference myRef =
            database.getReference("User").child(et_nama.getText().toString());

    //memberi nilai pada referensi yang dituju
    myRef.child("Ttl").setValue(et_ttl.getText().toString());
    myRef.child("Almt").setValue(et_almt.getText().toString());


}
}