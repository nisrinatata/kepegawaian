package com.example.kepegawaian;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Perusahaan {
    public String nama;
    public String ruangan;
    public String kategori;
    public String keluhan;
    public String foto;

    public Perusahaan() {
    }
    public Perusahaan(String nama,String ruangan, String kategori,  String keluhan, String foto) {
        this.nama = nama;
        this.ruangan = ruangan;
        this.kategori = kategori;
        this.keluhan = keluhan;
        this.foto = foto;
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("nama", nama);
        result.put("ruangan", ruangan);
        result.put("kategori", kategori);
        result.put("keluhan", keluhan);
        result.put("foto", foto);
        return result;
    }
}

