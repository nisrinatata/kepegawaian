package com.example.kepegawaian;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class KodeActivity extends AppCompatActivity {

    //Variable yang Dibutuhkan Untuk Autentikasi
    String verificationId;
    FirebaseAuth mAuth;

    Intent intent;

    //Variable Untuk Komponen-komponen Yang Diperlukan
    EditText et_otp;
    Button verify_btn;
    String otp;
    ProgressBar pb_bar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kode);

        et_otp = findViewById(R.id.et_otp);
        verify_btn = findViewById(R.id.login);
        pb_bar = findViewById(R.id.pb_bar);
        pb_bar.setVisibility(View.GONE);


        mAuth = FirebaseAuth.getInstance();

        intent = getIntent();
        verificationId = intent.getStringExtra("verificationId");


        verify_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                otp = et_otp.getText().toString().trim();

                if (!otp.isEmpty()) {
                    pb_bar.setVisibility(View.VISIBLE);
                    verifyOtp(verificationId, otp);
                    Intent intent = new Intent(KodeActivity.this, KeluhanActivity.class);
                    startActivity(intent);
                } else {
                    et_otp.setError("Invalid otp");
                }

            }
        });
    }

    private void verifyOtp(String verificationId, String otp) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, otp);

        //sign in user
        signInWithPhoneAuthCredential(credential);
    }

    // wktu user udh masukin kode verifikasi kmu login ke firebase authentication pake phoneCredential, biar data user yang login kesave
    // di firebase
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            pb_bar.setVisibility(View.INVISIBLE);
                            Intent intent = new Intent(KodeActivity.this, KeluhanActivity.class);
                            Toast.makeText(getApplicationContext(), "Verifikasi Telah Selesai", Toast.LENGTH_SHORT).show();
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(KodeActivity.this, "Something Wrong ",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(KodeActivity.this, "Something Wrong " + e, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
