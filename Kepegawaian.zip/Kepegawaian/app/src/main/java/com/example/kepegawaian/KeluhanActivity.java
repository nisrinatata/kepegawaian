package com.example.kepegawaian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class KeluhanActivity extends AppCompatActivity {


    RelativeLayout relativeLayout;
    AnimationDrawable animationDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keluhan);

        relativeLayout = (RelativeLayout) findViewById(R.id.form_keluhan);
        animationDrawable = (AnimationDrawable) relativeLayout.getBackground();


        animationDrawable.setEnterFadeDuration(5000);
        animationDrawable.setExitFadeDuration(2000);

    }


    @Override
    protected void onPause() {
        super.onPause();

        if (animationDrawable != null && animationDrawable.isRunning()){
            animationDrawable.stop();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (animationDrawable != null && !animationDrawable.isRunning()){
            animationDrawable.start();
        }
    }



    public void Click3(View view){

        EditText edt_form =  (EditText)findViewById(R.id.edt_form);
        EditText edt_ruangan =  (EditText)findViewById(R.id.edt_ruangan);
        EditText edt_kategori =  (EditText)findViewById(R.id.edt_kategori);
        EditText edt_keluhan =  (EditText)findViewById(R.id.edt_keluhan);
        EditText edt_status =  (EditText)findViewById(R.id.edt_status);
        EditText edt_koordinat = (EditText) findViewById(R.id.edt_koordinat);

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        //Referensi database yang dituju
        DatabaseReference myRef =
                database.getReference("Keluhan").child(edt_form.getText().toString());

        //memberi nilai pada referensi yang dituju
        myRef.child("Ruangan").setValue(edt_ruangan.getText().toString());
        myRef.child("Kategori").setValue(edt_kategori.getText().toString());
        myRef.child("Keluhan").setValue(edt_keluhan.getText().toString());
        myRef.child("Status").setValue(edt_status.getText().toString());
        myRef.child("Koordinat").setValue(edt_koordinat.getText().toString());

        Intent intent = new Intent(KeluhanActivity.this, MainActivity.class);
        startActivity(intent);
        finish();

        Toast.makeText(getApplicationContext(), "Data Keluhan Sudah Tersimpan", Toast.LENGTH_SHORT).show();
    }


}